/**
 * CircularLinkedList implementation
 * @author <Your Name Here>
 * @version 1.0
 */
public class CircularLinkedList<T> implements LinkedListInterface<T> {

    @Override
    public void addAtIndex(int index, T data) {
        
    }

    @Override
    public T get(int index) {
        
    }

    @Override
    public T removeAtIndex(int index) {
        
    }

    @Override
    public void addToFront(T t) {
        
    }

    @Override
    public void addToBack(T t) {
        
    }

    @Override
    public T removeFromFront() {
        
    }

    @Override
    public T removeFromBack() {
        
    }

    @Override
    public T[] toList() {
        
    }

    @Override
    public boolean isEmpty() {
        
    }

    @Override
    public int size() {
        
    }

    @Override
    public void clear() {
        
    }

    /**
     * Reference to the head node of the linked list.
     * Normally, you would not do this, but we need it
     * for grading your work.
     *
     * @return Node representing the head of the linked list
     */
    public Node<T> getHead() {
        
    }

    /**
     * Reference to the tail node of the linked list.
     * Normally, you would not do this, but we need it
     * for grading your work.
     *
     * @return Node representing the tail of the linked list
     */
    public Node<T> getTail() {
        
    }

    /**
     * This method is for your testing purposes.
     * You may choose to implement it if you wish.
     */
    @Override
    public String toString() {
        return "";
    }
}

